//
//  IBDesignables.h
//  IBDesignables
//
//  Created by Martin Vasilev on 4.08.18.
//  Copyright © 2018 Upnetix. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for IBDesignables.
FOUNDATION_EXPORT double IBDesignablesVersionNumber;

//! Project version string for IBDesignables.
FOUNDATION_EXPORT const unsigned char IBDesignablesVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <IBDesignables/PublicHeader.h>


