//
//  LocalizerKeys.swift
//  Skeleton
//
//  Created by Martin Vasilev on 15.11.18.
//  Copyright © 2018 Upnetix. All rights reserved.
//

import Foundation

struct LocalizerKeys {
    
}
